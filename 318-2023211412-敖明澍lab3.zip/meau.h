#pragma once
#include<stdio.h>
#include<stdlib.h>
#include"graphics.h"
#include<conio.h>
void meau() {
	outtextrect(0, 0, 400, 200, "welcome to the ams drawing board,", NULL);
	outtextrect(0, 20, 400, 200, "please select your option", NULL);
	outtextrect(0, 40, 400, 200, "1.reading the document", NULL);
	outtextrect(0, 60, 400, 200, "2.not reading the document", NULL);
	outtextrect(0, 80, 400, 200, "please type in your option", NULL);
}