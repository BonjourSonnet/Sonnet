//Lab��ҵ��һ��
#include<stdio.h>
#include<stdlib.h>
#include"graphics.h"
#include<conio.h>
#include"meau.h"
#include"read_file.h"
#include<string.h>
/**/
#include"EgeInput.h"
#include<fstream>
#include<iostream>
#pragma warning(disable:4996)
#include<array>
#include<vector>
#include <sstream>
#include<string>

void outtextrect(
	int x,
	int y,
	int w,
	int h,
	char* str,
	PIMAGE pimg = NULL
);

//color transformation
std::string colorConvert(color_t c) {
	if (c == GREEN) {
		return "green";
	}
	if (c == RED) {
		return "red";
	}
	if (c == BLUE) {
		return "blue";
	}
}

//define the struct that include the information of the patterns
int num_circle = 2;
int num_line = 3;
int num_poly = 2;
FILE* fp;

//the difinition of the classes
class Point {
private:
	int point_point[2];
public:
	Point() : point_point{ 400,400 } {}
	Point(int p1, int p2) :point_point{ p1,p2 } {}
	int getPoint1() { return point_point[0]; }
	int getPoint2() { return point_point[1]; }
};

class Color {
private:
	color_t color_fill;	//1 for red, 2 for green, 3 for blue
	color_t color_border;
public:
	Color() = default;
	Color(color_t c1, color_t c2) :color_fill(c1), color_border(c2) {}
	void setColor(color_t color_fill_temp, color_t color_border_temp) {
		color_fill = color_fill_temp;
		color_border = color_border_temp;
	}
	int get_fill() { return color_fill; }
	int get_border() { return color_border; }

};

class Shape {
public:
	color_t color_border;
	Shape() :color_border(GREEN) {};
	Shape(color_t color_border) {
		this->color_border = color_border;
	}
	color_t getColor_border() { return color_border; }
	color_t setColor_border(color_t color) { color_border = color; }
	virtual void draw() {}
};

static int count_cir = 0;
char choice_cir_color;
char choice_cir;
std::vector<std::string> split(const std::string& str, char delimiter) {
	std::vector<std::string> tokens;
	std::istringstream tokenStream(str);
	std::string token;
	while (std::getline(tokenStream, token, delimiter)) {
		tokens.push_back(token);
	}
	return tokens;
}


class Circle :public Shape {
private:
	int r;
	int heart[2];
	color_t* color_cir;
public:
	Circle() :r(500), heart{ 200,200 }, Shape() {
		count_cir++;
		color_cir = new color_t;
		*color_cir = GREEN;
	}
	Circle(int r, int heart1, int heart2) :
		heart{ heart1,heart2 } {
		count_cir++;
		color_cir = new color_t;
		*color_cir = GREEN;
	}
	Circle(const Circle& other) : r(other.r), heart{ other.heart[0], other.heart[1] }, Shape() {
		count_cir++;
		color_cir = new color_t;
		*color_cir = *other.color_cir;
	}
	~Circle() { count_cir--; }

	int getCount() { return count_cir; }
	int getR() { return r; }
	int getHeart1() {
		return heart[0];
	}
	int getHeart2() {
		return heart[1];
	}
	void setR(int r) { this->r = r; }
	void setHeart1(int heart0) { heart[0] = heart0; }
	void setHeart2(int heart1) { heart[0] = heart1; }

	//file operation
	void writeToFile() {
		std::ofstream outfile;
		outfile.open("D:/����/code/c++/lab/lab3/readme.txt");
		outfile << 1 << "\n";
		Circle ct;
		outfile << ct.getHeart1() << " " << ct.getHeart2() << " " << ct.getR() << "\n";
		outfile << colorConvert(ct.getColor_border()) << " " << 0 << "\n";
		outfile.close();
	}

	Circle readFromFile_c() {
		std::ifstream infile("D:/����/code/c++/lab/lab3/readme.txt");
		std::array <char*, 100>line;
		int j;
		for (int i = 0; !infile.eof(); i++) {
			infile.getline(line[i], 10);
			if (line[i] == "0") {	//read (only 1 type of the pattern is allowed)
				j = i;
			}
		}
		//transform string to int
		std::vector<std::string> data = split(line[j + 1], ' ');
		int num1 = std::stoi(data[0]);
		int num2 = std::stoi(data[1]);
		int num3 = std::stoi(data[3]);
		Circle c1(num2, num1, num3);
		return c1;
	}
	void draw() {
		xyprintf(0, 340, "whether to open the file(1y, 2n)");
		char choice_file_cir = getch();
		if (choice_file_cir == '1') {
			Circle c = c.readFromFile_c();
		}
		xyprintf(0, 340, "the size of circle:(1 for dertermine the size yourself, 2 for default)");
		choice_cir = getch();

		Color c_cir;
		if (choice_cir == '2') {
			Circle c1;
			setcolor(c1.getColor_border());
			circle(
				c1.getHeart1(),
				c1.getHeart2(),
				c1.getR()
			);
			xyprintf(0, 360, "the num of circle: %d", c1.getCount());
			c1.writeToFile();
		}
		if (choice_cir == '1') {
			xyprintf(0, 360, "the color of circle:(1 for Red,2 for Green,3 for Blue)");
			choice_cir_color = getch();

			if (choice_cir_color == '1') {
				c_cir.setColor(BLACK, RED);
			}
			if (choice_cir_color == '2') {
				c_cir.setColor(BLACK, GREEN);
			}
			if (choice_cir_color == '3') {
				c_cir.setColor(BLACK, BLUE);
			}
			setcolor(c_cir.get_border());

			xyprintf(0, 360, "input the information of the circle(r, heart0, heart1)");
			int r_temp = getInteger();
			int heart1 = getInteger();
			int heart2 = getInteger();
			Circle c2{ r_temp,heart1,heart2 };
			setcolor(c_cir.get_border());
			circle(r_temp, heart1, heart2);
			xyprintf(0, 380, "the num of circle: %d", c2.getCount());
			c2.writeToFile();
		}
	}
};



static int count_line;
class Line {
private:
	Point point_line[2];
public:
	Point p_t1{ 800,100 };
	Point p_t2{ 100,100 };
	Line() :point_line{ p_t1,p_t2 } { count_line++; }
	Line(Point p1, Point p2) :point_line{ p1,p2 } { count_line++; }
	~Line() { count_line--; }
	Point getLine1() { return point_line[0]; }
	Point getLine2() { return point_line[1]; }
	int getCount() { return count_line; }
	void setLine() {}
};

static int count_tri;
class Triangle :public Shape {
private:
	int point_tri[6];
	Color* c_tri;
public:

	Triangle() :point_tri{ 200,200,300,200,300,300 } {
		count_tri++;
		c_tri = new Color;
	}
	Triangle(int t1, int t2, int t3, int t4, int t5, int t6) :
		point_tri{ t1,t2,t3,t4,t5,t6 } {
		count_tri++;
		c_tri = new Color;
	}
	Triangle(const Triangle& other) : 
		point_tri{ other.point_tri[0], other.point_tri[1],
				  other.point_tri[2], other.point_tri[3],
				  other.point_tri[4], other.point_tri[5] } {
	}
	~Triangle() { count_tri--; }
	void writeToFile() {
		std::ofstream outfile;
		outfile.open("D:/����/code/c++/lab/lab3/readme.txt");
		outfile << 2 << "\n";
		Triangle tr1;
		int* point = tr1.getPoint_tri();
		outfile << point[0] << " " << point[1] << " " << point[3] << " " << point[4] << " " << point[5] <<
			" " << point[6] << "\n";
		outfile << colorConvert(tr1.getColor_border()) << " " << 0 << "\n";
		outfile.close();
	}


	int* getPoint_tri() { return point_tri; }
	void setPoint_tri1(int p) { point_tri[0] = p; }
	void setPoint_tri2(int p) { point_tri[1] = p; }
	void setPoint_tri3(int p) { point_tri[2] = p; }
	void setPoint_tri4(int p) { point_tri[3] = p; }
	void setPoint_tri5(int p) { point_tri[4] = p; }
	void setPoint_tri6(int p) { point_tri[5] = p; }
	void setColor_tri(color_t c1, color_t c2) {
		Color c_tri(c1, c2);
	}
	int getCount() { return count_tri; }



	Triangle readFromFile_c() {
		std::ifstream infile("D:/����/code/c++/lab/lab3/readme.txt");
		std::array <char*, 100>line;
		int j;
		for (int i = 0; !infile.eof(); i++) {
			infile.getline(line[i], 10);
			if (line[i] == "2") {	//read (only 1 type of the pattern is allowed)
				j = i;
			}
		}
		//transform string to int
		std::vector<std::string> data = split(line[j + 1], ' ');
		int num1 = std::stoi(data[0]);
		int num2 = std::stoi(data[1]);
		int num3 = std::stoi(data[2]);
		int num4 = std::stoi(data[3]);
		int num5 = std::stoi(data[4]);
		int num6 = std::stoi(data[5]);

		Triangle tri(num1, num2, num3, num4,num5,num6);
		return tri;
	}

	void draw() {

	}
};


static int count_rec;
class Rectangle_ :public Shape {
private:
	int point_rec[8];
public:
	Rectangle_() :point_rec{ 200,200,800,200,800,800,200,800 }, Shape() {}
	Rectangle_(int r1, int r2, int r3, int r4, int r5, int r6, int r7, int r8) :
		point_rec{ r1,r2,r3,r4,r5,r6,r7,r8 } {
	}
	Rectangle_(const Rectangle_& other) {
		for (int i = 0; i < 8; ++i) {
			point_rec[i] = other.point_rec[i];
		} 
	}
	int* getRecPoint() { return point_rec; }
	int getCount() { return count_rec; }

	void writeToFile() {
		std::ofstream outfile;
		outfile.open("D:/����/code/c++/lab/lab3/readme.txt");
		outfile << 3 << "\n";
		Rectangle_ rec1;
		int* point = rec1.getRecPoint();
		outfile << point[0] << " " << point[1] << " " << point[3] << " " << point[4] << " " << point[5] <<
			" " << point[6] << " " << point[7] << "\n";
		outfile << colorConvert(rec1.getColor_border()) << " " << 0 << "\n";
		outfile.close();
	}
	Rectangle_ readFromFile_c() {
		std::ifstream infile("D:/����/code/c++/lab/lab3/readme.txt");
		std::array <char*, 100>line;
		int j;
		for (int i = 0; !infile.eof(); i++) {
			infile.getline(line[i], 10);
			if (line[i] == "3") {	//read (only 1 type of the pattern is allowed)
				j = i;
			}
		}
		//transform string to int
		std::vector<std::string> data = split(line[j + 1], ' ');
		int num1 = std::stoi(data[0]);
		int num2 = std::stoi(data[1]);
		int num3 = std::stoi(data[2]);
		int num4 = std::stoi(data[3]);
		int num5 = std::stoi(data[4]);
		int num6 = std::stoi(data[5]);
		int num7 = std::stoi(data[6]);
		int num8 = std::stoi(data[7]);


		Rectangle_ rec(num1, num2, num3, num4, num5, num6, num7, num8);
		return rec;
	}
};


class Control {
public:
	Control() {
		initgraph(1280, 960, INIT_WITHLOGO);
		setbkcolor(BLACK);
	}
	~Control() {
		closegraph();
	}
};

//the num of the patterns
/*LINE myline[3] = {
	{{200,100,100,100}},
	{{400,200,100,100
	{{600,400,100,100}}
};
CIRCLE cir[2] = {
	{100,{1},{200,200}},		//color: 1 for red, 2 for green
	{100,{2},{400,400}},
};
POLY poly[2] = {
	{{400,600,600,700,400,800} ,{1}},
	{{800,200,400,400,800,400},{2}}
};*/

//define the struct that include the new information of the patterns
typedef struct {
	int r_new;
	int color_new;
	int heart_new[2];
}CIRCLE_N;
typedef struct {
	int point_line_new[4];
}LINE_N;
typedef struct {
	int point_poly_new[6];
	int color;
}POLY_N;

LINE_N* myline_new;
CIRCLE_N* cir_new;
POLY_N* poly_new;
int num_circle_new;
int num_line_new;
int num_poly_new;


//define 3 different fuction to read 3 patterns of data into the file
/*void writeToFile_c(CIRCLE* shapeArray);
void readFromFile();*/

int main() {

	Circle c1_test;
	Shape* sh1;
	sh1 = &c1_test;
	Circle c2_test(c1_test);
	circle(
		c2_test.getHeart1(),
		c2_test.getHeart2(),
		c2_test.getR()
	);

	Rectangle_ rec1;
	fillpoly(8, rec1.getRecPoint());
	/*first part, to decide whether we will read the document*/
	Control cont1;
	initgraph(1280, 960, INIT_WITHLOGO);
	setbkcolor(BLACK);
	//print the circle
	/*for (int i = 0; i < num_circle; i++) {
		circle(cir[i].r, cir[i].heart[0], cir[i].heart[1]);
	}
	//print the line
	for (int i = 0; i < num_line; i++) {
		fillpoly(2, myline[i].point_line);
	}
	//print the poly
	for (int i = 0; i < num_poly; i++) {
		fillpoly(3, poly[i].point_poly);
	}
	*/
	meau();

	int choice1 = read_file();
	//read the file
	/*if (choice1 == 0) {
		writeToFile_c(cir);
	}*/

	/*part two, to decide your operation*/
	char choice2 = 0;
	char choice_line;
	char choice_cir;
	Point p_line_def1;
	Point p_line_def2;
	char choice_tri;
	char choice_tri_color_fill;
	char choice_tri_color_bor = '0';
	char choice_rec;
	char choice_file;
	char choice_file_tr;
	char choice_file_rec;

	do {
		//ask the users the move
		outtextrect(0, 120, 400, 400, "welcome to the ams drawing board,", NULL);
		outtextrect(0, 140, 400, 400, "please select your option", NULL);
		outtextrect(0, 160, 400, 400, "1.clear the screen", NULL);
		outtextrect(0, 180, 400, 400, "2.draw the patterns in the file", NULL);
		outtextrect(0, 200, 400, 400, "3.exit", NULL);
		outtextrect(0, 220, 400, 400, "4.free drawing", NULL);
		outtextrect(0, 240, 400, 400, "5.draw a circle", NULL);
		outtextrect(0, 260, 400, 400, "6.draw a line", NULL);
		outtextrect(0, 280, 400, 400, "7.draw a triangle", NULL);
		outtextrect(0, 300, 400, 400, "8.draw a rectangle", NULL);
		outtextrect(0, 320, 400, 400, "please type in your option", NULL);

		/*use switch to select your operation*/
		char choice2 = getch();
		/*define the point of the graphic*/
		int pt[20];
		char points[100];
		switch (choice2) {


		case'1':
			xyprintf(0, 240, "cleared");
			clearviewport();
			break;

		case'2':
			//use the file to print the patterns
			//readFromFile();
			//print the circle

			for (int i = 0; i < (num_circle_new); i++) {
				if (cir_new[i].color_new == 1) {
					setcolor(RED);		//the color of outline
				}
				if (cir_new[i].color_new == 2) {
					setcolor(GREEN);
				}
				circle(cir_new[i].r_new, cir_new[i].heart_new[0], cir_new->heart_new[1]);
				setcolor(BLACK);
			}
			for (int i = 0; i < num_line_new; i++) {
				fillpoly(2, myline_new[i].point_line_new);
			}
			for (int i = 0; i < num_poly_new; i++) {
				if (poly_new[i].color == 1) {
					setfillcolor(RED);
				}
				if (poly_new[i].color == 2) {
					setfillcolor(GREEN);
				}

				fillpoly(3, poly_new[i].point_poly_new);
			}

			//free the memory
			free(cir_new);
			free(myline_new);
			free(poly_new);

			break;
		case'3':
			xyprintf(0, 240, "exit");
			closegraph();
			exit(0);
			break;
		case'4':
			xyprintf(0, 240, "free drawing");
			xyprintf(0, 260, "how many sides do you want to draw:");
			int side;
			side = getInteger("please input the side");

			for (int i = 0; i < side; i++) {
				xyprintf(0, 280, "please input the first int of the num%d coordinate", i + 1);
				pt[i * 2] = getInteger();
				for (; pt[i * 2] > 1280;) {
					xyprintf(0, 300, "error");
					xyprintf(0, 320, "please input again, the num should be under 1280");
					pt[i * 2] = getInteger();
				}
				xyprintf(0, 340, "please input the second int of the num%d coordinate", i + 1);
				pt[i * 2 + 1] = getInteger();
				for (; pt[i * 2 + 1] > 960;) {
					xyprintf(0, 360, "error");
					xyprintf(0, 380, "please input again, the num should be under 960");
					pt[i * 2 + 1] = getInteger();
				}
			}
			fillpoly(side, pt);

		case'5':
			sh1->draw();

			//I try to use the point to represent the dimention, but no idea why this part can't work
		case'6':		//line
			
			xyprintf(0, 340, "the size of line:(1 for dertermine the size yourself, 2 for default)");
			choice_line = getch();
			if (choice_line == '2') {
				Line l1;
				Point p_line_def1 = l1.getLine1();
				Point p_line_def2 = l1.getLine2();
				int lineToDraw[4] = {
					p_line_def1.getPoint1(), p_line_def1.getPoint2(),
					p_line_def2.getPoint1(), p_line_def2.getPoint2()
				};
				drawlines(1, lineToDraw);
				xyprintf(0, 360, "the num of line: %d", l1.getCount());

			}
			if (choice_line == '1') {
				xyprintf(0, 360, "input the information of the line(point1,point2,point3,poin4)");
				int p[4];
				p[0] = getInteger();
				p[1] = getInteger();
				p[2] = getInteger();
				p[3] = getInteger();
				Point p_temp1 = { p[0],p[1] };
				Point p_temp2 = { p[2],p[3] };
				Line l2{ p_temp1,p_temp2 };
				drawlines(1, p);
				xyprintf(0, 860, "the num of line: %d", l2.getCount());

			}
		case'7':		//triangle
			xyprintf(0, 340, "whether to open the file(1y, 2n)");
			choice_file_tr = getch();
			if (choice_file_tr == '1') {
				Triangle t = t.readFromFile_c();
			}
			xyprintf(0, 340, "the size of triangle:(1 for dertermine the size yourself, 2 for default)");
			choice_tri = getch();
			if (choice_tri == '2') {
				Triangle tr1;
				fillpoly(6, tr1.getPoint_tri());
				xyprintf(0, 400, "the num of triangle: %d", tr1.getCount());
				tr1.writeToFile();
			}
			xyprintf(0, 360, "the color of the fill of triangle:(1 for Red,2 for Green,3 for Blue)");
			choice_tri_color_fill = getch();
			xyprintf(0, 380, "the color of the border of triangle:(1 for Red,2 for Green,3 for Blue)");
			choice_tri_color_bor = getch();

			
			Color co_tri;
			//determine the color
			if (choice_tri_color_fill == '1') {
				if (choice_tri_color_bor == '1') {
					co_tri.setColor(RED, RED);
				}
				if (choice_tri_color_bor == '2') {
					co_tri.setColor(RED, GREEN);
				}
				if (choice_tri_color_bor == '3') {
					co_tri.setColor(RED, BLUE);
				}
			}
			if (choice_tri_color_fill == '2') {
				if (choice_tri_color_bor == '1') {
					co_tri.setColor(GREEN, RED);
				}
				if (choice_tri_color_bor == '2') {
					co_tri.setColor(GREEN, GREEN);
				}
				if (choice_tri_color_bor == '3') {
					co_tri.setColor(GREEN, BLUE);
				}
			}
			if (choice_tri_color_fill == '3') {
				if (choice_tri_color_bor == '1') {
					co_tri.setColor(BLUE, RED);
				}
				if (choice_tri_color_bor == '2') {
					co_tri.setColor(BLUE, GREEN);
				}
				if (choice_tri_color_bor == '3') {
					co_tri.setColor(BLUE, BLUE);
				}
			}
			setcolor(co_tri.get_border());
			setfillcolor(co_tri.get_fill());

			//draw the triangle

			if (choice_tri == '1') {
				Triangle tr2;
				int temp[6];
				for (int i = 0; i < 6; i++) {
					temp[i] = getInteger();
				}
				tr2.setPoint_tri1(temp[0]);
				tr2.setPoint_tri2(temp[1]);
				tr2.setPoint_tri3(temp[2]);
				tr2.setPoint_tri4(temp[3]);
				tr2.setPoint_tri5(temp[4]);
				tr2.setPoint_tri6(temp[5]);
				fillpoly(6, tr2.getPoint_tri());
				xyprintf(0, 400, "the num of triangle: %d", tr2.getCount());
				tr2.writeToFile();
			}
		case'8':	//rectangle
			xyprintf(0, 340, "whether to open the file(1y, 2n)");
			choice_file_rec = getch();
			if (choice_file_rec == '1') {
				Rectangle_ rec = rec.readFromFile_c();
				fillpoly(8, rec.getRecPoint());
				break;
			}
			xyprintf(0, 340, "the size of rectangle:(1 for dertermine the size yourself, 2 for default)");
			choice_rec = getch();
			if (choice_rec == '2') {
				Rectangle_ rec1;
				setcolor(rec1.getColor_border());
				fillpoly(8, rec1.getRecPoint());
				xyprintf(0, 360, "the num of rectangle: %d", rec1.getCount());
				rec1.writeToFile();
			}
		}


	} while (choice2 != '3');
	getch();
	//	closegraph();
	exit(0);
	return 0;
}

/*void writeToFile_c(CIRCLE* shapeArray) {
	fp = fopen("D:\\����\\code\\files\\lab4.txt", "w");

	//read the data of circle to the file
	fprintf(fp, "%d\n", num_circle);
	for (int i = 0; i < num_circle; i++) {
		fprintf(fp, "%d\t", cir[i].r);		//r comes first
		fprintf(fp, "%d\t", cir[i].color_c);
		fprintf(fp, "%d\t%d\n", cir[i].heart[0], cir[i].heart[1]);
	}

	//read the data of line to the file
	fprintf(fp, "%d\n", num_line);
	for (int i = 0; i < num_line; i++) {
		for (int j = 0; j < 4; j++) {
			fprintf(fp, "%d\t", myline[i].point_line[j]);
		}
		fprintf(fp, "\n");
	}

	//read the data of poly
	fprintf(fp, "%d\n", num_poly);
	for (int i = 0; i < num_poly; i++) {
		for (int j = 0; j < 6; j++) {
			fprintf(fp, "%d\t", poly[i].point_poly[j]);
		}
		fprintf(fp, "%d", poly[i].color);
		fprintf(fp, "\n");
	}
	fclose(fp);
}

void readFromFile() {

	//open the file for reading
	fp = fopen("D:\\����\\code\\files\\lab4.txt", "r");
	fscanf(fp, "%d", &num_circle_new);
	//allocate the memory
	cir_new = (CIRCLE_N*)malloc(sizeof(CIRCLE_N) * num_circle_new);
	if (cir_new == NULL) {
		printf("error");
	}
	//read the data of circle in the file
	for (int i = 0; i < num_circle_new; i++) {
		fscanf(fp, "%d", &cir_new[i].r_new);
		fscanf(fp, "%d", &cir_new[i].color_new);
		for (int j = 0; j < 2; j++) {
			fscanf(fp, "%d", &cir_new[i].heart_new[j]);
		}
	}

	//read the data of line in the file
	fscanf(fp, "%d", &num_line_new);
	myline_new = (LINE_N*)malloc(sizeof(LINE_N) * num_line_new);
	if (myline_new == NULL) {
		printf("error");
	}
	for (int i = 0; i < num_line_new; i++) {
		for (int j = 0; j < 4; j++) {
			fscanf(fp, "%d", &myline_new[i].point_line_new[j]);
		}
	}

	//read the data of poly in the file
	fscanf(fp, "%d", &num_poly_new);
	poly_new = (POLY_N*)malloc(sizeof(POLY_N) * num_poly_new);
	for (int i = 0; i < num_poly_new; i++) {
		for (int j = 0; j < 6; j++) {
			fscanf(fp, "%d", &poly_new[i].point_poly_new[j]);
		}
		fscanf(fp, "%d", &poly_new[i].color);
	}
}*/
