#pragma once
#include<stdio.h>
#include<stdlib.h>
#include"graphics.h"


/*decide whether to read the file*/
int read_file() {

	char choice1 = getch();
	if (choice1 == '1') {
		xyprintf(0, 100, "information read");
		return 0;
	}
	else {
		xyprintf(0, 100, "information not read");
		return 1;
	}
}
